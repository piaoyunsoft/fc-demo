$(function(){

  /* 导航 */
  var scrollTopList = [];
  for(var i = 0; i < $('#J_nav').find('li').length; i++){
    scrollTopList[i] = Number($('.no'+i).offset().top) - 80;
  }

  $('#J_nav').find('li').click(function(){
    var _this = $(this);
    var i = _this.index();
    _this.addClass('active').siblings('li').removeClass('active');
    $("html, body").animate({ scrollTop: scrollTopList[i] }, 300);
  });

  /* 导航跟随滚动 */
  $(window).scroll(function(){
    var scT = $(window).scrollTop();
    if(-100< scT && scT < 520){
      setStatus(0);
    }else if(520<= scT && scT < 904){
      setStatus(1);
    }else if(904<= scT && scT < 1378){
      setStatus(2);
    }else if(1378<= scT && scT < 2289){
      setStatus(3);
    }else{
      setStatus(4);
    }
  });


  function setStatus(i){
    $('#J_nav').find('li').eq(i).addClass('active').siblings('li').removeClass('active');
  }







  /* 产品介绍 */
  $('#J_goods').find('li').eq(0).addClass('active');
  $('#J_goods').find('li').on({
    'mouseover': function(){
      $(this).addClass('active').siblings('li').removeClass('active');
    }
  });
});